---
layout: home
permalink: /
---

Find [here](documents) misc. documents for applied research.


Source code for this page: [GitHub][myrepo]

[myrepo]: https://github.com/ClairePalandri/ClairePalandri.github.io
